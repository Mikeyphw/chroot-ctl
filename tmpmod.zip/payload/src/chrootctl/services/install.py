from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any

from ..base_install import ReleaseRef
from ..installer_factory import build_installer
from ..models import InstallRequest, InstallRunResult, InstallWizardDefaults, UpgradeResult
from ..user_sync import validate_username
from .context import ServiceContainer

PROFILE_OPTIONS = ("minimal", "dev", "xfce4", "plasma", "custom")
DESKTOP_OPTIONS = ("auto", "none", "xfce4", "plasma")
DISTRO_OPTIONS = ("ubuntu", "arch")


INSTALL_STEPS = (
    {
        "id": "validate",
        "label": "Validate request",
        "description": "Check distro, profile, username, and desktop rules before any filesystem changes.",
    },
    {
        "id": "extract",
        "label": "Extract base system",
        "description": "Download or locate the base rootfs and extract it into the chroot directory.",
    },
    {
        "id": "bootstrap",
        "label": "Bootstrap packages and user",
        "description": "Mount runtime filesystems, configure networking, install base packages, and create the user.",
    },
    {
        "id": "desktop",
        "label": "Desktop package pass",
        "description": "Install no desktop for minimal/dev profiles, or lightweight desktop packages when requested.",
    },
    {
        "id": "finalize",
        "label": "Finalize install",
        "description": "Run post-install hooks, sync metadata, and mark the chroot installed.",
    },
    {
        "id": "catalog",
        "label": "Apply selected tools/addons",
        "description": "Apply optional tools and addons only after finalize succeeds.",
    },
)


class InstallService:
    def __init__(self, services: ServiceContainer) -> None:
        self.services = services

    def distros(self) -> tuple[str, ...]:
        return DISTRO_OPTIONS

    def profiles(self) -> tuple[str, ...]:
        return PROFILE_OPTIONS

    def desktops(self) -> tuple[str, ...]:
        return DESKTOP_OPTIONS

    def profile_options(self) -> list[dict[str, object]]:
        return [
            {
                "id": profile,
                "label": _profile_label(profile),
                "desktop_allowed": profile not in {"minimal", "dev"},
                "default_desktop": "none" if profile in {"minimal", "dev", "custom"} else profile,
                "description": _profile_description(profile),
            }
            for profile in PROFILE_OPTIONS
        ]

    def desktop_options(self) -> list[dict[str, object]]:
        return [
            {
                "id": desktop,
                "label": _desktop_label(desktop),
                "lightweight": desktop in {"xfce4", "plasma"},
                "packages": _desktop_package_preview(desktop),
            }
            for desktop in DESKTOP_OPTIONS
        ]


    def list_target_users(self, *, name: str | None = None) -> list[dict[str, str]]:
        try:
            runtime = self.services.runtime_for(name)
            rows = runtime.chroot_users.user_rows()
        except Exception:
            return []
        users: list[dict[str, str]] = []
        seen: set[str] = set()
        for row in rows:
            username = str(getattr(row, "username", "")).strip()
            uid = str(getattr(row, "uid", "")).strip()
            if not username or username == "root" or uid == "0" or username in seen:
                continue
            users.append(
                {
                    "username": username,
                    "uid": uid or "unknown",
                    "gid": str(getattr(row, "gid", "")).strip() or "unknown",
                    "home": str(getattr(row, "home", "")).strip() or f"/home/{username}",
                    "shell": str(getattr(row, "shell", "")).strip() or "/bin/bash",
                }
            )
            seen.add(username)
        return users

    def install_form_state(self, *, name: str | None = None, distro: str | None = None) -> dict[str, Any]:
        defaults = self.wizard_defaults(name=name, distro=distro)
        users = self.list_target_users(name=name or defaults.name)
        return {
            "defaults": {
                "distro": defaults.distro,
                "name": defaults.name,
                "username": defaults.username,
                "profile": defaults.profile or "minimal",
                "desktop": defaults.desktop or "none",
                "release": defaults.release,
                "version": defaults.version,
            },
            "distros": [{"id": distro_id, "label": distro_id.title()} for distro_id in self.distros()],
            "profiles": self.profile_options(),
            "desktops": self.desktop_options(),
            "users": users,
            "requirements": {
                "username_required": True,
                "root_required": True,
            },
            "rules": {
                "minimal_forces_desktop": "none",
                "minimal_rejects_desktop": True,
                "ubuntu_desktop_packages": "lightweight-no-recommends",
            },
        }

    def validate_install_submission(self, request: InstallRequest) -> dict[str, Any]:
        blocking: list[dict[str, Any]] = []
        users = self.list_target_users(name=request.name)
        normalized_username = (request.username or "").strip()
        if not normalized_username:
            blocking.append(
                _blocking_issue(
                    code="missing_username",
                    message="No target user selected. Choose an existing non-root user or create a new target username.",
                    fix_label="Create user",
                    fix_href="/install#target-user-step",
                    secondary_label="Use advanced install with --username",
                    secondary_href="/install#target-user-step",
                )
            )
            return {
                "ok": False,
                "blocking": blocking,
                "warnings": [],
                "resolved": [],
                "plan": None,
                "users": users,
                "requirements": {"username_required": True},
            }

        try:
            plan = self.validate_install_request(request)
        except ValueError as exc:
            blocking.append(_map_install_error(str(exc)))
            return {
                "ok": False,
                "blocking": blocking,
                "warnings": [],
                "resolved": [],
                "plan": None,
                "users": users,
                "requirements": {"username_required": True},
            }

        resolved: list[str] = []
        requested_desktop = plan.get("requested_desktop")
        resolved_desktop = plan.get("desktop")
        if requested_desktop and resolved_desktop and requested_desktop != resolved_desktop:
            resolved.append(f"Desktop changed from {requested_desktop} → {resolved_desktop}.")
        if users and normalized_username not in {item["username"] for item in users}:
            resolved.append(f"Target user {normalized_username} will be created during install.")
        return {
            "ok": True,
            "blocking": [],
            "warnings": list(plan.get("warnings", ())),
            "resolved": resolved,
            "plan": plan,
            "users": users,
            "requirements": {"username_required": True},
        }

    def wizard_defaults(self, *, name: str | None = None, distro: str | None = None) -> InstallWizardDefaults:
        record = _preferred_record(self.services, name=name, distro=distro)
        selected_distro = distro
        selected_name = name
        release = None
        version = None
        profile = None
        desktop = None
        username = None
        if record is not None:
            selected_distro = selected_distro or str(record.get("distro") or "") or None
            selected_name = selected_name or str(record.get("name") or "") or None
            release = str(record.get("release_name") or "") or None
            version = str(record.get("version") or "") or None
            metadata = record.get("metadata", {})
            if isinstance(metadata, dict):
                profile = _metadata_value(metadata, "profile")
                desktop = _metadata_value(metadata, "desktop")
                username = _validated_username(_metadata_value(metadata, "username"))
        selected_name = selected_name or selected_distro
        if (profile or "minimal") == "minimal":
            desktop = "none"
        username = username or _default_username_hint(self.services, selected_name)
        return InstallWizardDefaults(
            distro=selected_distro,
            name=selected_name,
            username=username,
            profile=profile,
            desktop=desktop,
            release=release,
            version=version,
        )

    def install_feedback_plan(self, request: InstallRequest) -> dict[str, Any]:
        profile = (request.profile or "minimal").strip() or "minimal"
        requested_desktop = (request.desktop or "auto").strip() or "auto"
        resolved_desktop = "none"
        if profile == "minimal":
            if requested_desktop not in {"auto", "none"}:
                raise ValueError("minimal profile does not allow desktop installation; choose profile xfce4/plasma or desktop none")
        elif requested_desktop == "auto":
            resolved_desktop = next(
                (
                    str(item["default_desktop"])
                    for item in self.profile_options()
                    if item["id"] == profile
                ),
                "none",
            )
        else:
            resolved_desktop = requested_desktop
        selected_steps = [dict(step) for step in INSTALL_STEPS]
        if not request.tools and not request.addons:
            selected_steps = [step for step in selected_steps if step["id"] != "catalog"]
        return {
            "name": request.name,
            "distro": request.distro,
            "username": request.username,
            "profile": profile,
            "requested_desktop": requested_desktop,
            "desktop": resolved_desktop,
            "release": request.release or "auto",
            "version": request.version or "latest",
            "tools": list(request.tools),
            "addons": list(request.addons),
            "repair": request.repair,
            "steps": selected_steps,
            "total_steps": len(selected_steps),
            "warnings": _install_plan_warnings(profile=profile, desktop=resolved_desktop, tools=request.tools, addons=request.addons),
        }

    def validate_install_request(self, request: InstallRequest) -> dict[str, Any]:
        validate_username(request.username)
        if request.distro not in DISTRO_OPTIONS:
            raise ValueError(f"unsupported distro: {request.distro}")
        if (request.profile or "minimal") not in PROFILE_OPTIONS:
            raise ValueError(f"unsupported profile: {request.profile}")
        desktop = (request.desktop or "auto").strip() or "auto"
        if desktop not in DESKTOP_OPTIONS:
            raise ValueError(f"unsupported desktop: {desktop}")
        return self.install_feedback_plan(request)

    def list_versions(self, *, distro: str, name: str | None = None, username: str | None = None) -> list[ReleaseRef]:
        config_name = name or distro
        runtime = self.services.runtime_for(config_name, username=username or self.services.base_config.username)
        installer = build_installer(
            distro,
            runtime.config,
            runtime.runner,
            runtime.controller,
            self.services.registry,
            runtime.user_sync,
            self.services.logger,
        )
        return installer.list_versions()

    def install(
        self,
        request: InstallRequest,
        *,
        progress: Callable[[str], None] | None = None,
    ) -> InstallRunResult:
        runtime = self.services.runtime_for(request.name, username=request.username)
        installer = build_installer(
            request.distro,
            runtime.config,
            runtime.runner,
            runtime.controller,
            self.services.registry,
            runtime.user_sync,
            self.services.logger,
        )
        plan = self.validate_install_request(request)
        phase_results = []
        if progress is not None:
            progress({
                "phase": "validate",
                "message": "Install request validated",
                "percent": 8,
                "plan": plan,
                "current_step": 1,
                "total_steps": plan["total_steps"],
            })
            progress({
                "phase": "extract",
                "message": "Running install phases",
                "percent": 12,
                "plan": plan,
                "current_step": 2,
                "total_steps": plan["total_steps"],
            })
        phase_index = {"extract": 2, "bootstrap": 3, "desktop": 4, "finalize": 5}
        for item in installer.install(
            phase=request.phase,
            username=request.username,
            desktop=request.desktop,
            version=request.version,
            release=request.release,
            force_phase=request.force_phase,
            auto=False,
            resume=request.resume,
            repair=request.repair,
            profile=request.profile,
        ):
            phase_results.append(item)
            phase_name = str(getattr(item, "phase", "install"))
            if progress is not None:
                step_number = min(phase_index.get(phase_name, len(phase_results) + 1), plan["total_steps"])
                progress({
                    "phase": phase_name,
                    "message": f"Completed phase: {phase_name}",
                    "percent": min(92, int((step_number / max(plan["total_steps"], 1)) * 92)),
                    "plan": plan,
                    "current_step": step_number,
                    "total_steps": plan["total_steps"],
                    "result": item,
                })
        tool_results = []
        addon_results = []
        record = self.services.registry.get(request.name)
        if (request.tools or request.addons) and (record is None or not bool(record.get("installed"))):
            raise RuntimeError("tools and addons can only be applied after finalize completes")
        if (request.tools or request.addons) and progress is not None:
            progress({
                "phase": "catalog",
                "message": "Applying selected tools and addons",
                "percent": 94,
                "plan": plan,
                "current_step": plan["total_steps"],
                "total_steps": plan["total_steps"],
            })
        if request.tools:
            tool_results = self.services.catalog("tool", name=request.name).apply(list(request.tools), progress=progress)
        if request.addons:
            addon_results = self.services.catalog("addon", name=request.name).apply(list(request.addons), progress=progress)
        next_steps = tuple(_install_next_steps(request.name, username=request.username))
        if progress is not None:
            progress({
                "phase": "complete",
                "message": "Install completed",
                "percent": 100,
                "plan": plan,
                "current_step": plan["total_steps"],
                "total_steps": plan["total_steps"],
            })
        return InstallRunResult(
            chroot_name=request.name,
            distro=request.distro,
            phases=tuple(phase_results),
            tool_results=tuple(tool_results),
            addon_results=tuple(addon_results),
            next_steps=next_steps,
        )

    def upgrade(
        self,
        name: str,
        *,
        username: str | None = None,
        progress: Callable[[str], None] | None = None,
    ) -> UpgradeResult:
        record = self.services.registry.get(name)
        if record is None:
            raise RuntimeError(f"no registry record for chroot: {name}")
        target_username = username or _default_username_hint(self.services, name) or self.services.base_config.username
        if not target_username:
            raise RuntimeError("upgrade requires a username")
        runtime = self.services.runtime_for(name, username=target_username)
        installer = build_installer(
            str(record.get("distro") or ""),
            runtime.config,
            runtime.runner,
            runtime.controller,
            self.services.registry,
            runtime.user_sync,
            self.services.logger,
        )
        if progress is not None:
            progress("Upgrading chroot")
        result = installer.upgrade()
        if progress is not None:
            progress("Upgrade completed")
        return UpgradeResult(
            status=result.status,
            snapshot=result.snapshot,
            next_steps=(
                f"chrootctl --name {name} restart",
                f"chrootctl --name {name} logs --all",
            ),
        )




def _blocking_issue(
    *,
    code: str,
    message: str,
    fix_label: str | None = None,
    fix_href: str | None = None,
    secondary_label: str | None = None,
    secondary_href: str | None = None,
) -> dict[str, Any]:
    issue = {
        "code": code,
        "message": message,
    }
    actions: list[dict[str, str]] = []
    if fix_label and fix_href:
        actions.append({"label": fix_label, "href": fix_href})
    if secondary_label and secondary_href:
        actions.append({"label": secondary_label, "href": secondary_href})
    if actions:
        issue["actions"] = actions
    return issue


def _map_install_error(message: str) -> dict[str, Any]:
    lowered = message.lower()
    if "no non-root users available" in lowered or "username" in lowered:
        return _blocking_issue(
            code="missing_username",
            message="No non-root users are available. Choose or create a user before installing this chroot.",
            fix_label="Create user",
            fix_href="/install#target-user-step",
            secondary_label="Use advanced install with --username",
            secondary_href="/install#target-user-step",
        )
    if "dependency" in lowered or "missing deps" in lowered:
        return _blocking_issue(
            code="missing_dependency",
            message="Python dependency missing. Open module status or review the suggested fix command before retrying.",
            fix_label="Open module status",
            fix_href="/ksu",
            secondary_label="Open checks",
            secondary_href="/doctor",
        )
    if "minimal profile does not allow desktop" in lowered:
        return _blocking_issue(
            code="desktop_profile_conflict",
            message="Minimal profile cannot install a desktop. Switch to XFCE/Plasma or keep desktop set to none.",
            fix_label="Switch profile",
            fix_href="/install#profile-step",
            secondary_label="Keep minimal",
            secondary_href="/install#profile-step",
        )
    return _blocking_issue(code="invalid_request", message=message)



def _install_plan_warnings(*, profile: str, desktop: str, tools: tuple[str, ...], addons: tuple[str, ...]) -> list[str]:
    warnings: list[str] = []
    if profile == "minimal" and desktop == "none":
        warnings.append("Minimal profile will skip desktop package installation.")
    if desktop in {"xfce4", "plasma"}:
        warnings.append("Desktop installation uses lightweight packages with --no-install-recommends.")
    if tools or addons:
        warnings.append("Tools and addons run after finalize; failures there do not mean base extraction failed.")
    return warnings

def _preferred_record(services: ServiceContainer, *, name: str | None = None, distro: str | None = None):
    if name:
        record = services.registry.get(name)
        if record is not None:
            return record
    rows = list(services.registry.list())
    incomplete = [row for row in rows if not bool(row.get("installed"))]
    if len(incomplete) == 1:
        return services.registry.get(str(incomplete[0]["name"]))
    if distro is not None:
        matches = [row for row in rows if str(row.get("distro", "")) == distro]
        if len(matches) == 1:
            return services.registry.get(str(matches[0]["name"]))
    if len(rows) == 1:
        return services.registry.get(str(rows[0]["name"]))
    return None


def _metadata_value(metadata: object, key: str) -> str | None:
    if not isinstance(metadata, dict):
        return None
    value = metadata.get(key)
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _validated_username(value: str | None) -> str | None:
    if value is None:
        return None
    try:
        return validate_username(value)
    except ValueError:
        return None


def _default_username_hint(services: ServiceContainer, chroot_name: str | None) -> str | None:
    try:
        runtime = services.runtime_for(chroot_name)
        existing = [row.username for row in runtime.chroot_users.user_rows() if row.username != "root" and str(getattr(row, "uid", "")) != "0"]
    except Exception:
        existing = []
    if len(existing) == 1:
        return existing[0]
    env_user = os.environ.get("USER", "").strip()
    if env_user and env_user != "root":
        try:
            return validate_username(env_user)
        except ValueError:
            return None
    configured = services.base_config.username
    if configured and configured != "root" and configured != "mike":
        try:
            return validate_username(configured)
        except ValueError:
            return None
    return None


def _install_next_steps(name: str, *, username: str) -> list[str]:
    return [
        f"chrootctl --name {name} start",
        f"chrootctl --name {name} users sync-id {username}",
        f"chrootctl --name {name} logs --all",
    ]

def _profile_label(profile: str) -> str:
    labels = {
        "minimal": "Minimal",
        "dev": "Developer",
        "xfce4": "XFCE Desktop",
        "plasma": "KDE Plasma Desktop",
        "custom": "Custom",
    }
    return labels.get(profile, profile.replace("_", " ").replace("-", " ").title())


def _profile_description(profile: str) -> str:
    descriptions = {
        "minimal": "Base system only. No desktop environment is installed.",
        "dev": "Developer-focused base image with CLI tooling and no desktop.",
        "xfce4": "Balanced desktop profile with XFCE packages preselected.",
        "plasma": "Full desktop profile with KDE Plasma packages preselected.",
        "custom": "Start from a minimal base and choose packages manually.",
    }
    return descriptions.get(profile, "Install profile.")


def _desktop_label(desktop: str) -> str:
    labels = {
        "auto": "Automatic",
        "none": "None",
        "xfce4": "XFCE",
        "plasma": "KDE Plasma",
    }
    return labels.get(desktop, desktop.replace("_", " ").replace("-", " ").title())


def _desktop_package_preview(desktop: str) -> str:
    previews = {
        "auto": "Installer chooses the best desktop for the selected profile.",
        "none": "Base system only.",
        "xfce4": "xfce4, xfce4-goodies, xorg",
        "plasma": "plasma-desktop, sddm, xorg",
    }
    return previews.get(desktop, "Desktop packages selected by installer.")
