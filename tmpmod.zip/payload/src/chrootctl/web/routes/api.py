from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from ...models import InstallRequest
from ..deps import get_jobs, get_services, resolve_log_path
from ..serialize import serialize_value

router = APIRouter(prefix="/api", tags=["api"])


class InstallValidationRequest(BaseModel):
    distro: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    username: str | None = None
    profile: str | None = None
    desktop: str | None = None
    release: str | None = None
    version: str | None = None
    tools: list[str] = Field(default_factory=list)
    addons: list[str] = Field(default_factory=list)
    repair: bool = False


class ActionRequest(BaseModel):
    action: str = Field(..., min_length=1)
    target: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


@router.get("/state")
def state(request: Request, services=Depends(get_services), jobs=Depends(get_jobs)) -> dict[str, Any]:
    security = request.app.state.web_security
    chroots = _chroot_summary(services)
    lifecycle = _lifecycle_status(services, host=security.bind_host, port=security.bind_port)
    recent_jobs = [job.to_event_payload() for job in jobs.list_recent(limit=5, tail=5)]
    last_error = next((job.error for job in jobs.list_recent(limit=20, tail=0) if job.error), None)
    return {
        "server": lifecycle,
        "module": lifecycle["module"],
        "python": lifecycle["python"],
        "chroots": chroots,
        "jobs": {
            "recent": recent_jobs,
            "active": sum(1 for job in jobs.list_recent(limit=100, tail=0) if not job.complete),
        },
        "last_error": last_error,
    }


@router.get("/install/options")
def install_options(services=Depends(get_services), distro: str | None = None, name: str | None = None) -> dict[str, Any]:
    install = services.install()
    defaults = install.wizard_defaults(name=name, distro=distro)
    return install.install_form_state(name=name, distro=distro)




@router.post("/install/validate")
def validate_install(payload: InstallValidationRequest, services=Depends(get_services)) -> dict[str, Any]:
    install_request = InstallRequest(
        distro=payload.distro,
        name=payload.name,
        username=(payload.username or "").strip(),
        profile=_optional_str(payload.profile),
        desktop=_optional_str(payload.desktop),
        release=_optional_str(payload.release),
        version=_optional_str(payload.version),
        tools=tuple(payload.tools),
        addons=tuple(payload.addons),
        repair=payload.repair,
    )
    result = services.install().validate_install_submission(install_request)
    if not result["ok"]:
        raise HTTPException(status_code=400, detail=result)
    return result


@router.post("/actions")
def actions(request: ActionRequest, services=Depends(get_services), jobs=Depends(get_jobs)) -> dict[str, Any]:
    action = request.action.strip().lower()
    target = (request.target or request.payload.get("name") or "").strip() or None
    if action in {"webui-start", "webui-stop", "webui-restart"}:
        lifecycle = _lifecycle_service(services)
        result = {
            "webui-start": lifecycle.start_webui,
            "webui-stop": lifecycle.stop_webui,
            "webui-restart": lifecycle.restart_webui,
        }[action]()
        return {"job_id": None, "status": "completed", "result": result}

    if action in {"start", "restart", "mount", "unmount", "status", "doctor", "logs"}:
        if not target:
            raise HTTPException(status_code=400, detail="target is required for chroot actions")
        job = jobs.submit(
            kind=f"chroot-{action}",
            title=f"{action.title()} {target}",
            target_name=target,
            log_path=resolve_log_path(services, name=target),
            runner=lambda progress: _run_chroot_action(services, action=action, target=target, progress=progress),
        )
        return {"job_id": job.job_id, "status": job.state, "location": f"/jobs/{job.job_id}"}

    if action == "install":
        install_request = _install_request_from_payload(request.payload)
        validation = services.install().validate_install_submission(install_request)
        if not validation["ok"]:
            raise HTTPException(status_code=400, detail=validation)
        job = jobs.submit(
            kind="install",
            title=f"Install {install_request.name}",
            target_name=install_request.name,
            log_path=resolve_log_path(services, name=install_request.name, username=install_request.username),
            runner=lambda progress: services.install().install(install_request, progress=progress),
        )
        return {"job_id": job.job_id, "status": job.state, "location": f"/jobs/{job.job_id}"}

    raise HTTPException(status_code=400, detail=f"unsupported action: {action}")


@router.get("/jobs/{job_id}")
def job_status(job_id: str, jobs=Depends(get_jobs), tail: int = Query(50, ge=0, le=500)) -> dict[str, Any]:
    try:
        return jobs.get(job_id, tail=tail).to_event_payload()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="job not found") from exc


@router.get("/logs/unified")
def api_logs(
    source: str = Query("webui"),
    name: str | None = None,
    tail: int = Query(100, ge=1, le=1000),
    services=Depends(get_services),
) -> dict[str, Any]:
    lifecycle = _lifecycle_service(services)
    log_file = _log_source_path(lifecycle, source=source, name=name, services=services)
    lines = _tail_file(log_file, tail=tail)
    return {
        "source": source,
        "name": name,
        "path": str(log_file),
        "exists": log_file.exists(),
        "tail": tail,
        "lines": lines,
    }


def _chroot_summary(services) -> dict[str, Any]:
    rows = services.chroots().list()
    mounted = 0
    failed = 0
    details: list[dict[str, Any]] = []
    for row in rows:
        running = False
        try:
            status_rows = services.system().status(row.name)
            running = bool(status_rows) and all(getattr(item, "result", "") == "PASS" for item in status_rows)
            mounted += 1 if running else 0
        except Exception:
            failed += 1
        details.append(
            {
                "name": row.name,
                "distro": row.distro,
                "phase": row.phase,
                "installed": row.installed,
                "running": running,
            }
        )
    return {
        "installed": sum(1 for row in rows if row.installed),
        "registered": len(rows),
        "mounted": mounted,
        "running": mounted,
        "failed": failed,
        "items": details,
    }


def _run_chroot_action(services, *, action: str, target: str, progress) -> Any:
    progress(f"Running {action} for {target}")
    if action == "start":
        return services.chroots().start(target)
    if action == "restart":
        return services.chroots().restart(target)
    if action == "status":
        return services.system().status(target)
    if action == "doctor":
        return services.system().doctor(target)
    if action == "logs":
        return services.system().logs(target)
    runtime = services.runtime_for(target)
    if action == "mount":
        return runtime.controller.mount()
    if action == "unmount":
        return runtime.controller.unmount()
    raise RuntimeError(f"unsupported chroot action: {action}")


def _install_request_from_payload(payload: dict[str, Any]) -> InstallRequest:
    try:
        return InstallRequest(
            distro=str(payload["distro"]),
            name=str(payload["name"]),
            username=str(payload["username"]),
            profile=_optional_str(payload.get("profile")),
            desktop=_optional_str(payload.get("desktop")),
            release=_optional_str(payload.get("release")),
            version=_optional_str(payload.get("version")),
            tools=tuple(str(item) for item in payload.get("tools", ()) or ()),
            addons=tuple(str(item) for item in payload.get("addons", ()) or ()),
            repair=bool(payload.get("repair", False)),
        )
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=f"missing install field: {exc.args[0]}") from exc


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _log_source_path(lifecycle, *, source: str, name: str | None, services):
    normalized = source.strip().lower()
    if normalized == "webui":
        return lifecycle.paths.webui_log_file
    if normalized == "install":
        return lifecycle.paths.install_log_file
    if normalized in {"dependencies", "dependency"}:
        return lifecycle.paths.dependency_log_file
    if normalized in {"chroot", "target"}:
        return services.config_for(name).log_file
    return lifecycle.paths.webui_log_file


def _tail_file(path, *, tail: int) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except FileNotFoundError:
        return []
    return lines[-tail:]


class _FallbackLifecycle:
    class paths:
        from pathlib import Path
        webui_log_file = Path("/data/adb/modules/chrootctl-magisk/var/log/chrootctl-webui.log")
        install_log_file = Path("/data/adb/modules/chrootctl-magisk/config/chrootctl/python-detection.txt")
        dependency_log_file = Path("/data/adb/modules/chrootctl-magisk/config/chrootctl/dependency-bootstrap.log")

    def status(self, *, host: str = "127.0.0.1", port: int = 8420):
        return {
            "running": True,
            "state": "running",
            "url": f"http://{host}:{port}",
            "module": {"id": "chrootctl-magisk", "version": None, "installed": False},
            "python": {"dependencies_ready": True, "missing": []},
        }

    def start_webui(self):
        return {"ok": True, "action": "start", "fallback": True}

    def stop_webui(self):
        return {"ok": True, "action": "stop", "fallback": True}

    def restart_webui(self):
        return {"ok": True, "action": "restart", "fallback": True}


def _lifecycle_service(services):
    if hasattr(services, "lifecycle"):
        return services.lifecycle()
    return _FallbackLifecycle()


def _lifecycle_status(services, *, host: str, port: int):
    return _lifecycle_service(services).status(host=host, port=port)
