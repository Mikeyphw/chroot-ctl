from __future__ import annotations

import os
import platform
import pwd
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence
import logging

CHROOT_ENV_BLOCKLIST = {
    "LD_PRELOAD",
    "LD_LIBRARY_PATH",
    "LD_AUDIT",
    "PYTHONPATH",
    "PREFIX",
    "TERMUX_VERSION",
    "TERMUX_APK_RELEASE",
    "ANDROID_ROOT",
    "ANDROID_DATA",
    "EXTERNAL_STORAGE",
    "TMPDIR",
    "TMP",
    "TEMP",
}

CHROOT_ENV_DEFAULTS = {
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    "HOME": "/root",
    "USER": "root",
    "SHELL": "/bin/bash",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TMPDIR": "/tmp",
    "TMP": "/tmp",
    "TEMP": "/tmp",
}

@dataclass(slots=True)
class RunResult:
    returncode: int
    stdout: str
    stderr: str

class SystemRunner:
    def __init__(self, logger: logging.Logger, dry_run: bool = False) -> None:
        self.logger = logger
        self.dry_run = dry_run

    def run(
        self,
        args: Sequence[str],
        *,
        check: bool = True,
        env: dict[str, str] | None = None,
        clean_env: bool = False,
        chroot_env: bool = False,
        capture_output: bool = True,
        cwd: Path | None = None,
        input_text: str | None = None,
    ) -> RunResult:
        self.logger.debug("run: %s", shlex.join(list(args)))
        if self.dry_run:
            return RunResult(returncode=0, stdout="", stderr="")
        process_env = {} if clean_env else os.environ.copy()
        if chroot_env:
            for key in CHROOT_ENV_BLOCKLIST:
                process_env.pop(key, None)
            process_env.update(CHROOT_ENV_DEFAULTS)
            process_env["TERM"] = os.environ.get("TERM") or "xterm-256color"
        if env is not None:
            process_env.update(env)
        completed = subprocess.run(
            list(args),
            check=False,
            env=process_env,
            capture_output=capture_output,
            input=input_text,
            text=True,
            cwd=str(cwd) if cwd else None,
        )
        result = RunResult(
            returncode=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
        )
        if check and result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or f"command failed: {shlex.join(list(args))}")
        return result

    def require_root(self) -> None:
        if os.geteuid() != 0:
            raise PermissionError("root privileges required")

    def is_root(self) -> bool:
        return os.geteuid() == 0

    def sudo_available(self) -> bool:
        return shutil.which("sudo") is not None

    def reexec_with_sudo(self, argv: list[str]) -> int:
        if self.dry_run:
            self.logger.info("dry-run sudo re-exec: %s", shlex.join(["sudo", *argv]))
            return 0
        if not self.sudo_available():
            raise PermissionError("sudo is not available and root is required")
        completed = subprocess.run(["sudo", *argv], check=False)
        return completed.returncode

    def python_reexec_argv(self) -> list[str]:
        return [sys.executable, *sys.argv]

    def mount_table(self) -> set[tuple[str, str]]:
        mounts: set[tuple[str, str]] = set()
        try:
            with open("/proc/mounts", "r", encoding="utf-8") as handle:
                for line in handle:
                    parts = line.split()
                    if len(parts) >= 2:
                        mounts.add((parts[0], parts[1]))
        except FileNotFoundError:
            pass
        return mounts

    def host_termux_uid_gid(self, termux_home: Path) -> tuple[int, int]:
        stat = termux_home.stat()
        return stat.st_uid, stat.st_gid


    def host_arch(self) -> str:
        machine = platform.machine().lower()
        aliases = {
            "x86_64": "amd64",
            "amd64": "amd64",
            "aarch64": "arm64",
            "arm64": "arm64",
        }
        return aliases.get(machine, machine)

    def current_username(self) -> str:
        return pwd.getpwuid(os.getuid()).pw_name
