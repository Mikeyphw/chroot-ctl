#!/system/bin/sh
MODDIR="${0%/*}"
case "$MODDIR" in
  */system/bin) MODDIR="${MODDIR%/system/bin}" ;;
esac
ACTIVE_MODULE="/data/adb/modules/chrootctl-magisk"
UPDATE_MODULE="/data/adb/modules_update/chrootctl-magisk" # diagnostics only

if [ -n "${CHROOTCTL_MODULE_DIR:-}" ]; then
  MODDIR="$CHROOTCTL_MODULE_DIR"
elif [ -d "$ACTIVE_MODULE" ]; then
  MODDIR="$ACTIVE_MODULE"
fi

if [ "$MODDIR" != "$ACTIVE_MODULE" ]; then
  echo "refusing module service outside active module: $MODDIR" >&2
  exit 0
fi

export CHROOTCTL_MODULE_DIR="$MODDIR"
HELPER="$MODDIR/bin/chrootctl-magisk-helper"
LOGGER="$MODDIR/bin/chrootctl-log-helper"
[ -x "$HELPER" ] || { [ -x "$LOGGER" ] && "$LOGGER" module "service helper-missing" || true; exit 0; }
[ -x "$LOGGER" ] && "$LOGGER" module "service begin" || true
"$HELPER" __module-service || true
[ -x "$LOGGER" ] && "$LOGGER" module "service end" || true
