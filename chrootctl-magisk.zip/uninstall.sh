#!/system/bin/sh
set -u
LOGGER=/data/adb/modules/chrootctl-magisk/bin/chrootctl-log-helper
[ -x "$LOGGER" ] && "$LOGGER" module "uninstall begin" || true
STATE_ROOT=/data/adb/chrootctl
[ -n "${CHROOTCTL_STATE_ROOT:-}" ] && STATE_ROOT="$CHROOTCTL_STATE_ROOT"
if [ -d "$STATE_ROOT" ]; then
  rm -f "$STATE_ROOT/bin/chrootctl" 2>/dev/null || true
  rmdir "$STATE_ROOT/bin" 2>/dev/null || true
  rm -f "$STATE_ROOT/control.state" "$STATE_ROOT/android-app.enabled" "$STATE_ROOT/clipboard-daemon.pid" "$STATE_ROOT/clipboard-daemon.token" "$STATE_ROOT/clipboard-daemon.identity.json" 2>/dev/null || true
  rm -f "$STATE_ROOT/clipboard.sock" 2>/dev/null || true
fi
exit 0
