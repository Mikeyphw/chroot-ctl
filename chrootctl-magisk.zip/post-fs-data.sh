#!/system/bin/sh
set -u
MODDIR="${CHROOTCTL_MODULE_DIR:-/data/adb/modules/chrootctl-magisk}"
STATE_ROOT=/data/adb/chrootctl
[ -n "${CHROOTCTL_STATE_ROOT:-}" ] && STATE_ROOT="$CHROOTCTL_STATE_ROOT"
BIN_DIR="$STATE_ROOT/bin"
RCLONE_DIR="$STATE_ROOT/rclone"
PUBLIC="$BIN_DIR/chrootctl"
SOURCE="$MODDIR/system/bin/chrootctl"
LOG_HELPER="$MODDIR/bin/chrootctl-log-helper"
[ -x "$LOG_HELPER" ] && "$LOG_HELPER" module "post-fs-data begin module=$MODDIR" || true

# KernelSU legacy does not necessarily expose module system/bin through magic
# mount. Maintain a root-owned stable launcher outside the module mount tree.
[ -d "$MODDIR" ] || exit 0
[ -f "$SOURCE" ] && [ -x "$SOURCE" ] && [ ! -L "$SOURCE" ] || exit 0
mkdir -p "$BIN_DIR" "$RCLONE_DIR" || exit 0
chown 0:0 "$STATE_ROOT" "$BIN_DIR" "$RCLONE_DIR" 2>/dev/null || true
chmod 0700 "$STATE_ROOT" "$BIN_DIR" "$RCLONE_DIR" 2>/dev/null || true
[ ! -f "$RCLONE_DIR/rclone.conf" ] || { chown 0:0 "$RCLONE_DIR/rclone.conf" 2>/dev/null || true; chmod 0600 "$RCLONE_DIR/rclone.conf" 2>/dev/null || true; }
cat > "$PUBLIC.tmp" <<'EOF'
#!/system/bin/sh
MODDIR="${CHROOTCTL_MODULE_DIR:-/data/adb/modules/chrootctl-magisk}"
exec "$MODDIR/system/bin/chrootctl" "$@"
EOF
chown 0:0 "$PUBLIC.tmp" 2>/dev/null || true
chmod 0755 "$PUBLIC.tmp" || { rm -f "$PUBLIC.tmp"; exit 0; }
mv -f "$PUBLIC.tmp" "$PUBLIC"
restorecon "$PUBLIC" 2>/dev/null || true
[ -x "$LOG_HELPER" ] && "$LOG_HELPER" module "post-fs-data stable-launcher-refreshed" || true
exit 0
