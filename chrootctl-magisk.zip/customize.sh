#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""
LOG_HELPER="${MODPATH:-}/bin/chrootctl-log-helper"
[ -x "$LOG_HELPER" ] && "$LOG_HELPER" module "installer begin" || true

ui_print "chrootctl ships a bundled Go native runtime." 2>/dev/null || echo "chrootctl ships a bundled Go native runtime."

# Magisk/KernelSU extraction may leave module payload files as 0644 even when
# the ZIP records executable modes. Enforce executable bits during install so
# /system/bin/chrootctl can exec the bundled Go runtime after promotion.
if [ -n "${MODPATH:-}" ] && [ -d "$MODPATH" ]; then
  if command -v set_perm_recursive >/dev/null 2>&1; then
    set_perm_recursive "$MODPATH" 0 0 0755 0644
  else
    chown -R 0:0 "$MODPATH" 2>/dev/null || true
    find "$MODPATH" -type d -exec chmod 0755 {} + 2>/dev/null || true
    find "$MODPATH" -type f -exec chmod 0644 {} + 2>/dev/null || true
  fi

  if command -v set_perm >/dev/null 2>&1; then
    set_perm "$MODPATH/customize.sh" 0 0 0755
    set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
    set_perm "$MODPATH/service.sh" 0 0 0755
    set_perm "$MODPATH/uninstall.sh" 0 0 0755
    set_perm "$MODPATH/bin/chrootctl-magisk-helper" 0 0 0755
    set_perm "$MODPATH/bin/chrootctl-log-helper" 0 0 0755
    set_perm "$MODPATH/system/bin/chrootctl" 0 0 0755
    set_perm "$MODPATH/system/bin/chrootctl-magisk-helper" 0 0 0755
    set_perm "$MODPATH/runtime/arm64-v8a/chrootctl" 0 0 0755
    [ ! -f "$MODPATH/runtime/arm64-v8a/rclone" ] || set_perm "$MODPATH/runtime/arm64-v8a/rclone" 0 0 0755
  else
    chmod 0755 "$MODPATH/customize.sh" 2>/dev/null || true
    chmod 0755 "$MODPATH/post-fs-data.sh" 2>/dev/null || true
    chmod 0755 "$MODPATH/service.sh" 2>/dev/null || true
    chmod 0755 "$MODPATH/uninstall.sh" 2>/dev/null || true
    chmod 0755 "$MODPATH/bin/chrootctl-magisk-helper" 2>/dev/null || true
    chmod 0755 "$MODPATH/bin/chrootctl-log-helper" 2>/dev/null || true
    chmod 0755 "$MODPATH/system/bin/chrootctl" 2>/dev/null || true
    chmod 0755 "$MODPATH/system/bin/chrootctl-magisk-helper" 2>/dev/null || true
    chmod 0755 "$MODPATH/runtime/arm64-v8a/chrootctl" 2>/dev/null || true
    [ ! -f "$MODPATH/runtime/arm64-v8a/rclone" ] || chmod 0755 "$MODPATH/runtime/arm64-v8a/rclone" 2>/dev/null || true
  fi

  # Existing installs are live-updated as well as left staged for the root
  # manager.  Build a complete sibling from the active tree first, overlay
  # only module-owned payload paths, then swap directories with rename(2).
  # This preserves manager marker files and gives us a rollback point.
  ACTIVE_MODULE="/data/adb/modules/chrootctl-magisk"
  if [ -d "$ACTIVE_MODULE" ] && [ "$MODPATH" != "$ACTIVE_MODULE" ]; then
    LIVE_PARENT="${ACTIVE_MODULE%/*}"
    LIVE_NEXT="$LIVE_PARENT/.chrootctl-magisk.live-new.$$"
    LIVE_OLD="$LIVE_PARENT/.chrootctl-magisk.live-old.$$"
    LIVE_OK=1
    rm -rf "$LIVE_NEXT" "$LIVE_OLD" 2>/dev/null || true
    mkdir -p "$LIVE_NEXT" || LIVE_OK=0
    [ "$LIVE_OK" -eq 0 ] || cp -a "$ACTIVE_MODULE/." "$LIVE_NEXT/" || LIVE_OK=0

    if [ "$LIVE_OK" -eq 1 ]; then
      for rel in module.prop customize.sh post-fs-data.sh service.sh uninstall.sh bin system config runtime webroot; do
        rm -rf "$LIVE_NEXT/$rel" || { LIVE_OK=0; break; }
        [ ! -e "$MODPATH/$rel" ] || cp -a "$MODPATH/$rel" "$LIVE_NEXT/$rel" || { LIVE_OK=0; break; }
      done
    fi

    for required in module.prop post-fs-data.sh service.sh system/bin/chrootctl runtime/arm64-v8a/runtime-manifest.json runtime/arm64-v8a/chrootctl config/chrootctl/module-package-manifest.json; do
      [ "$LIVE_OK" -eq 0 ] || [ -f "$LIVE_NEXT/$required" ] || LIVE_OK=0
    done
    [ "$LIVE_OK" -eq 0 ] || [ -x "$LIVE_NEXT/system/bin/chrootctl" ] || LIVE_OK=0
    [ "$LIVE_OK" -eq 0 ] || [ -x "$LIVE_NEXT/runtime/arm64-v8a/chrootctl" ] || LIVE_OK=0

    if [ "$LIVE_OK" -eq 1 ]; then
      chown -R 0:0 "$LIVE_NEXT" 2>/dev/null || true
      restorecon -RF "$LIVE_NEXT" 2>/dev/null || true
      if mv "$ACTIVE_MODULE" "$LIVE_OLD" && mv "$LIVE_NEXT" "$ACTIVE_MODULE"; then
        rm -rf "$LIVE_OLD" 2>/dev/null || true
        export CHROOTCTL_MODULE_DIR="$ACTIVE_MODULE"
        "$ACTIVE_MODULE/post-fs-data.sh" >/dev/null 2>&1 || true
        if [ ! -e "$ACTIVE_MODULE/disable" ] && [ ! -e "$ACTIVE_MODULE/remove" ]; then
          "$ACTIVE_MODULE/service.sh" >/dev/null 2>&1 || true
        fi
        [ -x "$ACTIVE_MODULE/bin/chrootctl-log-helper" ] && "$ACTIVE_MODULE/bin/chrootctl-log-helper" module "installer live-update success" || true
        ui_print "chrootctl active module updated live; reboot is not required for the module runtime/WebUI." 2>/dev/null || echo "chrootctl active module updated live; reboot is not required for the module runtime/WebUI."
        ui_print "Root-manager magic-mount changes, if any, may still require a reboot." 2>/dev/null || true
      else
        rm -rf "$LIVE_NEXT" 2>/dev/null || true
        if [ ! -d "$ACTIVE_MODULE" ] && [ -d "$LIVE_OLD" ]; then mv "$LIVE_OLD" "$ACTIVE_MODULE" 2>/dev/null || true; fi
        [ -x "$LOG_HELPER" ] && "$LOG_HELPER" module "installer live-update failed staged-fallback=true" || true
        ui_print "chrootctl live activation failed; staged update is preserved for reboot activation." 2>/dev/null || echo "chrootctl live activation failed; staged update is preserved for reboot activation."
      fi
    else
      rm -rf "$LIVE_NEXT" "$LIVE_OLD" 2>/dev/null || true
      [ -x "$LOG_HELPER" ] && "$LOG_HELPER" module "installer live-update preflight-failed staged-fallback=true" || true
      ui_print "chrootctl live activation preflight failed; staged update is preserved for reboot activation." 2>/dev/null || true
    fi
  fi
fi

return 0 2>/dev/null || exit 0
